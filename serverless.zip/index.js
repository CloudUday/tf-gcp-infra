const mailgun = require('mailgun-js');
const mysql = require('mysql');
const dotenv = require('dotenv');
const { v4: uuidv4 } = require('uuid');
dotenv.config();
const dbConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT
};
console.log({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT
});
const pool = mysql.createPool(dbConfig);

const DOMAIN = 'mg.udaygattu.me'; // Your Mailgun subdomain
const mg = mailgun({ apiKey: 'fcd8ecbd3f75b50856de06444bdb4699-4c205c86-7e1aae65', domain: DOMAIN }); // Your Mailgun API key



exports.sendVerificationEmail = async (pubSubEvent, context) => {
  const message = pubSubEvent.data ? Buffer.from(pubSubEvent.data, 'base64').toString() : '{}';
  const userData = JSON.parse(message);
  const { userId, username, fullName } = userData;

  // Generate a unique verification token for the user
  const verificationToken = uuidv4();
  const verificationLink = `https://udaygattu.me/v1/user/verify?token=${verificationToken}`;


const emailData = {
    from: 'postmaster@mg.udaygattu.me',
    to: username, // Assuming 'username' is the email address
    subject: 'Please verify your email address',
    html: `<h1>Email Verification</h1><p>Hello ${fullName},</p><p>Please click on the link below to verify your email address:</p><a href="${verificationLink}">Verify Email</a><p>This link will expire in 2 minutes.</p>`,
  };

  try {
    // Send email
    const body = await mg.messages().send(emailData);
    console.log('Email sent:', body);

    // Update user status in the database
    await updateEmailSentStatus(userId, verificationToken);
  } catch (error) {
    console.error('An error occurred:', error);
  }


async function updateEmailSentStatus(userId, verificationToken) {
  const query = `UPDATE Users SET verificationToken = '${verificationToken}', mailSentAt = NOW() WHERE id = '${userId}'`;

  pool.getConnection((err, connection) => {
    if (err) throw err; // not connected!

    connection.query(query, [userId], (error, results) => {
      connection.release();

      if (error) {
        console.error('Error updating email sent status:', error);
        return;
      }

      console.log(`Email sent status updated for user ID: ${userId}`);
    });
  });
 }}
